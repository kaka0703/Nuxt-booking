import Vue from 'vue'
import VueYoutube from 'vue-youtube'

Vue.use(VueYoutube);
