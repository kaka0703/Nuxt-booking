import Vue from 'vue';
import Flickity from 'vue-flickity';
require('flickity-as-nav-for');
require('flickity-imagesloaded');

Vue.component('flickity', Flickity);
