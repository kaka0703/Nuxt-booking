import Vue from 'vue'
const moment = require('vue-moment');
Vue.use(moment);
