<script>
    import Faq from "~/pages/_lang/faq";
    export default Faq;
</script>

