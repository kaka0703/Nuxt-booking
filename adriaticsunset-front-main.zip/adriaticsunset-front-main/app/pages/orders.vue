<script>
    import Orders from "~/pages/_lang/orders";
    export default Orders;
</script>

