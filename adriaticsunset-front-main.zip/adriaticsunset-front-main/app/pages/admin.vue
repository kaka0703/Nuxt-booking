<script>
    import Admin from "~/pages/_lang/admin";
    export default Admin;
</script>

