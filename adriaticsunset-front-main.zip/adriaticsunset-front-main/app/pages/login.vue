<script>
    import Login from "~/pages/_lang/login";
    export default Login;
</script>
