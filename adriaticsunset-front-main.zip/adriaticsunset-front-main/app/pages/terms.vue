<script>
    import Terms from "~/pages/_lang/terms";
    export default Terms;
</script>

