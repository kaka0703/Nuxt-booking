<h1>Your order has been canceled!</h1>

<pre>
    <?php var_dump($_GET); ?>
</pre>