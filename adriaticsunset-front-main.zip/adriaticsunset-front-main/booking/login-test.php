<form action ="https://www.adriaticsunsets.com/booking/login" method="POST">
    <input name="username" type="text" value="">
    <input name="password" type="text" value="">
    <button type="submit">GO</button>
</form>